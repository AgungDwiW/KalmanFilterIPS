# 2-D Kalman Filter for tracking a moving object.

Accompanying code for tutorial "Object Tracking: 2-D Object Tracking using Kalman Filter in Python"
Tutorial's link:
https://machinelearningspace.com/object-tracking-2-d-object-tracking-using-kalman-filter-in-python/

This code has been tested on Windows 10 using Anaconda.

Requirements:
- Python 3.7 
- opencv 4.2

Cheers,

Rahmad

